# solar-challenge-week1

Solar Challenge - Week 1 This project sets up the development environment for the Solar Challenge.